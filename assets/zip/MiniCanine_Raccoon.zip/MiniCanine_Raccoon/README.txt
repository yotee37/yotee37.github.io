Please include:

"Texture by Yotee37"

On the description of the avatar when uploading.

Consider supporting me on Ko-fi:
https://ko-fi.com/yotee37

Thank you!